package com.crystalkey.app.ui

import androidx.compose.runtime.Composable
import androidx.compose.ui.tooling.preview.Preview
import com.crystalkey.app.SessionViewModel
import com.crystalkey.app.theme.CrystalKeyTheme
import com.crystalkey.core.Dealer
import com.crystalkey.core.Seat
import com.crystalkey.core.SeatId
import com.crystalkey.core.SessionState

/**
 * Previews render in the design pane with no device and no emulator — the
 * fastest way to look at a screen, and the only way to see all party sizes at
 * once without playing four sessions.
 */
private fun previewSeats(n: Int): List<Seat> {
    val names = listOf("Mom", "Dad", "Leo", "Mia", "Gran", "Sam & Ada")
    return (0 until n).map { i ->
        val hero = Art.heroForSeat(i)
        Seat(SeatId(i + 1), names[i], hero.id, hero.band, buddy = i == 5)
    }
}

private fun previewLobby(n: Int, allReady: Boolean) = SessionState.Lobby(
    roomCode = "JUNGLE24",
    seats = previewSeats(n),
    ready = if (allReady) previewSeats(n).map { it.id }.toSet() else setOf(SeatId(1), SeatId(2)),
)

@Preview(name = "1 · Title", widthDp = 390, heightDp = 845, showBackground = true)
@Composable
private fun TitlePreview() {
    CrystalKeyTheme { TitleScreen(onHost = {}, onJoin = {}) }
}

@Preview(name = "2 · Lobby, 4 seats", widthDp = 390, heightDp = 845, showBackground = true)
@Composable
private fun LobbyFourPreview() {
    val state = previewLobby(4, allReady = false)
    CrystalKeyTheme {
        LobbyScreen(
            state = state,
            deal = Dealer.deal(state.seats, SessionViewModel.SYNC_PATTERN, 42L, 0),
            onAddSeat = { _, _ -> }, onReady = {}, onStart = {},
        )
    }
}

@Preview(name = "2b · Lobby, 6 seats", widthDp = 390, heightDp = 845, showBackground = true)
@Composable
private fun LobbySixPreview() {
    val state = previewLobby(6, allReady = true)
    CrystalKeyTheme {
        LobbyScreen(
            state = state,
            deal = Dealer.deal(state.seats, SessionViewModel.SYNC_PATTERN, 42L, 0),
            onAddSeat = { _, _ -> }, onReady = {}, onStart = {},
        )
    }
}

@Preview(name = "3 · Chapter intro", widthDp = 390, heightDp = 845, showBackground = true)
@Composable
private fun ChapterPreview() {
    CrystalKeyTheme { ChapterScreen(chapter = 1, onEnter = {}) }
}

@Preview(name = "4 · Cards, seat 1", widthDp = 390, heightDp = 845, showBackground = true)
@Composable
private fun CardsFirstPreview() {
    val seats = previewSeats(4)
    CrystalKeyTheme {
        SeatCardsScreen(
            seats = seats,
            deal = Dealer.deal(seats, SessionViewModel.SYNC_PATTERN, 42L, 0),
            viewing = seats[0].id, onView = {}, onBack = {},
        )
    }
}

@Preview(name = "4b · Cards, seat 3 — different", widthDp = 390, heightDp = 845, showBackground = true)
@Composable
private fun CardsThirdPreview() {
    val seats = previewSeats(4)
    CrystalKeyTheme {
        SeatCardsScreen(
            seats = seats,
            deal = Dealer.deal(seats, SessionViewModel.SYNC_PATTERN, 42L, 0),
            viewing = seats[2].id, onView = {}, onBack = {},
        )
    }
}
