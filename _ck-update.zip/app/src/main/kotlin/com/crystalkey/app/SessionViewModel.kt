package com.crystalkey.app

import androidx.lifecycle.ViewModel
import com.crystalkey.app.ui.Art
import com.crystalkey.core.AgeBand
import com.crystalkey.core.Atom
import com.crystalkey.core.AtomId
import com.crystalkey.core.Deal
import com.crystalkey.core.Dealer
import com.crystalkey.core.Interrogative
import com.crystalkey.core.PartyRules
import com.crystalkey.core.PuzzleSpec
import com.crystalkey.core.Seat
import com.crystalkey.core.SeatId
import com.crystalkey.core.SessionEvent
import com.crystalkey.core.SessionReducer
import com.crystalkey.core.SessionState
import com.crystalkey.core.TurnPlan
import com.crystalkey.core.TurnPlanner
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Holds the session and forwards every change through the verified reducer.
 *
 * Nothing here decides game rules. The view model's only jobs are to own the
 * current state, to generate a session seed once, and to ask the core for the
 * deal and the turn plan — so that the properties proved in the core test suite
 * are the properties the UI actually gets.
 */
class SessionViewModel : ViewModel() {

    private val _state = MutableStateFlow<SessionState>(SessionState.Idle)
    val state: StateFlow<SessionState> = _state.asStateFlow()

    private val _deal = MutableStateFlow<Deal?>(null)
    val deal: StateFlow<Deal?> = _deal.asStateFlow()

    private val _turn = MutableStateFlow<TurnPlan?>(null)
    val turn: StateFlow<TurnPlan?> = _turn.asStateFlow()

    /**
     * Which seat's screen is being shown.
     *
     * On a real table this is always "mine" and never changes. Until the local
     * transport exists every seat is on one device, so the cards screen lets you
     * step between them — which turns out to be the clearest way to show a new
     * person why the room has to talk.
     */
    private val _viewingSeat = MutableStateFlow<SeatId?>(null)
    val viewingSeat: StateFlow<SeatId?> = _viewingSeat.asStateFlow()

    fun viewAs(seat: SeatId) { _viewingSeat.value = seat }

    fun reset() {
        _state.value = SessionState.Idle
        _deal.value = null
        _turn.value = null
        _viewingSeat.value = null
    }

    fun dispatch(event: SessionEvent) {
        _state.value = SessionReducer.reduce(_state.value, event)
    }

    fun hostRoom(code: String = randomRoomCode()) = dispatch(SessionEvent.HostRoom(code))

    /**
     * Seats are handed a hero from the roster in join order, so a portrait shows
     * up the moment somebody sits down rather than after a separate setup step.
     */
    fun joinSeat(displayName: String, band: AgeBand, buddy: Boolean = false) {
        val taken = seatsInLobby()
        val hero = Art.heroForSeat(taken)
        dispatch(SessionEvent.SeatJoined(Seat(SeatId(taken + 1), displayName, hero.id, band, buddy)))
    }

    fun toggleReady(seat: SeatId) = dispatch(SessionEvent.SeatReady(seat))

    /**
     * Starts the quest and derives the first deal.
     *
     * The seed is generated once and then everything is a pure function of it,
     * which is why no device has to be the authority on who holds what.
     */
    fun startQuest(seed: Long = System.nanoTime()) {
        dispatch(SessionEvent.StartQuest(seed))
        val party = SessionReducer.partyOf(_state.value) ?: return
        val deal = Dealer.deal(party.seats, SYNC_PATTERN, party.sessionSeed, round = 0)
        _deal.value = deal
        _turn.value = TurnPlanner
            .planRotation(party.seats, deal, party.rules, party.sessionSeed, chapter = 1)
            .firstOrNull()
        _viewingSeat.value = party.seats.firstOrNull()?.id
    }

    fun rules(): PartyRules? = SessionReducer.partyOf(_state.value)?.rules

    private fun seatsInLobby(): Int = (_state.value as? SessionState.Lobby)?.seats?.size ?: 0

    companion object {

        fun randomRoomCode(): String {
            val word = listOf("JUNGLE", "CAVERN", "EMBER", "TIDE", "STAR", "STONE").random()
            return word + (10..99).random()
        }

        /** The worked example from the design canvas, authored at six atoms. */
        val SYNC_PATTERN = PuzzleSpec(
            id = "lanternwood.sync-pattern",
            title = "The Sync Pattern",
            atoms = listOf(
                Atom(AtomId(1), Interrogative.HOW, "the table — which stones exist and where"),
                Atom(AtomId(2), Interrogative.WHAT, "the order — the sequence they follow"),
                Atom(AtomId(3), Interrogative.WHEN, "the beat — the window to lock one in"),
                Atom(AtomId(4), Interrogative.WHERE, "the shape — what the door is asking for"),
                Atom(AtomId(5), Interrogative.WHY, "the trap — the stone that must stay dark"),
                Atom(AtomId(6), Interrogative.HOW_MANY, "the count — placements before the spike"),
            ),
        )
    }
}
