package com.crystalkey.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.lifecycle.viewmodel.compose.viewModel
import com.crystalkey.app.theme.CrystalKeyTheme
import com.crystalkey.app.ui.ChapterScreen
import com.crystalkey.app.ui.LobbyScreen
import com.crystalkey.app.ui.SeatCardsScreen
import com.crystalkey.app.ui.TitleScreen
import com.crystalkey.core.SessionEvent
import com.crystalkey.core.SessionReducer
import com.crystalkey.core.SessionState

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { CrystalKeyTheme { App() } }
    }
}

/**
 * Every reachable state is routed explicitly.
 *
 * There used to be an `else -> TitleScreen()` fallback here, which meant
 * starting a quest silently dropped the player back on the title with dead
 * buttons. A `when` over a sealed interface does not need a fallback — if a new
 * state is added, this stops compiling, which is the point.
 */
@Composable
private fun App(vm: SessionViewModel = viewModel()) {
    val state by vm.state.collectAsState()
    val deal by vm.deal.collectAsState()
    val viewing by vm.viewingSeat.collectAsState()

    when (val s = state) {
        is SessionState.Idle ->
            TitleScreen(onHost = { vm.hostRoom() }, onJoin = { vm.hostRoom() })

        is SessionState.Hosting, is SessionState.Joining, is SessionState.Lobby ->
            LobbyScreen(
                state = s,
                deal = deal,
                onAddSeat = { name, band -> vm.joinSeat(name, band) },
                onReady = { vm.toggleReady(it) },
                onStart = { vm.startQuest() },
            )

        is SessionState.ChapterIntro ->
            ChapterScreen(chapter = s.chapter, onEnter = { vm.dispatch(SessionEvent.EnterMap) })

        is SessionState.QuestMap ->
            SeatCardsScreen(
                seats = s.party.seats,
                deal = deal,
                viewing = viewing ?: s.party.seats.first().id,
                onView = { vm.viewAs(it) },
                onBack = { vm.dispatch(SessionEvent.End(com.crystalkey.core.EndReason.CLOSED_BY_HOST)) },
            )

        // Screens for these are next on the list; until then they read as the
        // cards screen rather than pretending to be something they are not.
        is SessionState.PuzzleTurn, is SessionState.BossStage,
        is SessionState.ObjectiveComplete, is SessionState.Debrief,
        is SessionState.Paused, is SessionState.Frozen -> {
            val party = SessionReducer.partyOf(s)
            if (party == null) {
                TitleScreen(onHost = { vm.hostRoom() }, onJoin = { vm.hostRoom() })
            } else {
                SeatCardsScreen(
                    seats = party.seats,
                    deal = deal,
                    viewing = viewing ?: party.seats.first().id,
                    onView = { vm.viewAs(it) },
                    onBack = { vm.reset() },
                )
            }
        }
    }
}
